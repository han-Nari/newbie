<?php 
	require_once "../includes/finance_db_connect.php";
	require_once "../includes/session.php";
	require_once "../finance/expense_fetch.php";
		
	$admin_id = $_SESSION['email'];

	if(!isset($admin_id)){
	   header('location:../login.php');
	}

	unset($_SESSION["passCode"]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">
		window.history.forward();
	</script>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Dashboard</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="\test\finance\img\logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php require_once "dash.css"; ?>
	</style>
</head>
<body>
	<main>
	<!-- Sidebar -->
	<?php require_once "side.php";?>

	<!-- Header -->
	<?php require_once "header.php";?>

	<!-- Main content -->
		<section>
			<h1 class="title block">Dashboard</h1>
			<div class="col_one">
                <div class="cards bg-1">
                    <span class="icon">
                        <i class="fa-solid fa-file-circle-plus"></i>
                    </span>
                    <span class="textss">
                        <span>Expense Management</span>
                        <p class="count"><?php echo expense($pdo); ?></p>
                    </span>
                    </span>
                </div>
                <div class="cards bg-2">
                    <span class="icon">
                        <i class="fa-solid fa-file"></i>
                    </span>
                    <span class="textss">
                        <span>Income Management</span>
                        <p class="count"><?php echo tax($pdo); ?></p>
                    </span>
                </div>
                <div class="cards bg-3">
                    <span class="icon">
                        <i class="fa-solid fa-user-tie"></i>
                    </span>
                    <span class="textss">
                        <span>Admin</span>
                        <p class="count">1<?php// echo rowCount($pdo); ?></p>
                    </span>
                </div>
                <div class="cards bg-4">
                    <span class="icon">
                        <i class="fa-solid fa-user-tie"></i>
                    </span>
                    <span class="textss">
                        <span>Data</span>
                        <p class="count">1<?php// echo rowCount($pdo); ?></p>
                    </span>
                    <span class="views">
                    	<a class="view" href="../connected/data.php">View</a>
                    </span>
                </div>
                 <div class="cards bg-2">
                    <span class="icon">
                        <i class="fa-solid fa-user-tie"></i>
                    </span>
                    <span class="textss">
                        <span>Data 2</span>
                        <p class="count">1<?php// echo rowCount($pdo); ?></p>
                    </span>
                    <span class="views">
                    	<a class="view" href="view.php">View</a>
                    </span>
                </div>
            </div>
		</section>
	</main>
	<script>
		<?php require_once "dash.js"; ?>
	</script>
</body>
</html>



	