<?php 
	$errors = array("username" => "", "password" => "", "email" => "", "img" => "");

	if(isset($_GET["id"])) {
		try {
			$id = htmlspecialchars($_GET["id"]);

			$query = "SELECT * FROM tax WHERE id = :id";
			$stmt = $pdo->prepare($query);
			$stmt->bindParam(":id", $id);
			$stmt->execute();

			$results = $stmt->fetch(PDO::FETCH_ASSOC);
		} catch(PDOException $e) {
			die("Error" . $e->getMessage());
		}
	}

	
	if(isset($_POST["update"])) {
		function dataInput($data) {
	       $data = trim($data);
	       $data = stripslashes($data);
	       $data = htmlspecialchars($data);
	       return $data;
	    }

       $assessedValue = $_POST['assessedValue'];
	   $basicTax = $_POST['basicTax'];
	   $sef = $_POST['sef'];
	   $totalTax = $_POST['totalTax'];

	   if(empty($assessedValue) && empty($basicTax) && empty($sef) && empty($totalTax)) {
			$errors["error"] = "Please fill up the form properly!";
	   }
	   
	   if(array_filter($errors)) {

	   } else {
		   $query = "UPDATE `tax` SET assessed_value = :assessed_value, basic_tax = :basic_tax, sef = :sef, total_tax = :total_tax  WHERE id = :id";
		   $stmt = $pdo->prepare($query);
		   $stmt->bindParam(":assessed_value", $assessedValue);
	       $stmt->bindParam(":basic_tax", $basicTax);
		   $stmt->bindParam(":sef", $sef);
		   $stmt->bindParam(":total_tax", $totalTax);
		   $stmt->bindParam(":id", $id);
		   $stmt->execute();
		   if($stmt) {
		   	  $_SESSION["success"] = "Update Sucessful!";
		   	   header('location: tax_db.php');
		   }
	   }

	   
	}
