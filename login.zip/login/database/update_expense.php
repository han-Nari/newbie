<?php 
$errors = array("expenses" => "", "amount" => "", "desc" => "");

if(isset($_GET["id"])) {
	try {
		$id = htmlspecialchars($_GET["id"]);

		$query = "SELECT * FROM expenses WHERE id = :id";
		$stmt = $pdo->prepare($query);
		$stmt->bindParam(":id", $id);
		$stmt->execute();

		$results = $stmt->fetch(PDO::FETCH_ASSOC);
	} catch(PDOException $e) {
		die("Error" . $e->getMessage());
	}
}

if(isset($_POST["update"])) {
		function dataInput($data) {
	       $data = trim($data);
	       $data = stripslashes($data);
	       $data = htmlspecialchars($data);
	       return $data;
	    }

	    $expenseType = $_POST['newExpense'];
	    $amount = $_POST['amount'];
	    $description = $_POST['description'];

	    // Errors handlers
		if(empty($expenseType)) {
			$errors["expenses"] = "Fill up the form!";
		} elseif(!preg_match('/^[a-zA-Z]+$/', $expenseType)) {
			$errors["expenses"] = "Only letter is allowed!";
		}

		if(empty($amount)) {
			$errors["amount"] = "Fill up the form!";
		}

		if(empty($description)) {
			$errors["desc"] = "Fill up the form!";
		} elseif(!preg_match('/^[a-zA-Z]+$/', $expenseType)) {
			$errors["desc"] = "Only letter is allowed!";
		}

      if(array_filter($errors)) {

      } else {
	   
		   $query = "UPDATE `expenses` SET type = :type, amount = :amount, particulars = :particulars WHERE id = :id";
		   $stmt = $pdo->prepare($query);
		   $stmt->bindParam(":type", $expenseType);
	       $stmt->bindParam(":amount", $amount);
		   $stmt->bindParam(":particulars", $description);
		   $stmt->bindParam(":id", $id);
		   $stmt->execute();
		   if($stmt) {
		   	  $_SESSION["success"] = "Update Sucessful!";
		   	   header('location: expenses_db.php');
		   }
      }

	   
	}
