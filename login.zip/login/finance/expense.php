<?php 
	require_once "../includes/session.php";
	require_once "../includes/finance_db_connect.php";
	require_once "save_expense.php";

	$admin_id = $_SESSION['email'];

	if (!isset($admin_id)) {
	    header('location:../login.php');
	}

	unset($_SESSION["passCode"]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">
		window.history.forward();
	</script>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Philippine Real Property Tax Calculator</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../img/logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php include "../dashboard/dash.css"; ?>
		<?php include "expense.css"; ?>
	</style>
</head>
<body>
	<main>
	<!-- Sidebar -->
	<?php include "../dashboard/side.php";?>

	<!-- Header -->
	<?php include "../dashboard/header.php";?>

	<!-- Main content -->
		<section>
			<?php if(isset($_SESSION['message'])) : ?>
				<div class="sub">
					<strong><?php echo $_SESSION['message'];?></strong>
					<i class="fa-solid fa-xmark remove"></i>
				</div>
				<?php unset($_SESSION['message']); ?>
			<?php endif; ?>	
		    <form id="expenseForm" action="<?php htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
		      <h1 class="expense">Barangay Expense Management System</h1>

		      <label for="newExpense">Expense Type</label>
		      <input type="text" id="newExpense" name="newExpense" placeholder="Expense Type">

		      <span class="errors">
				<?php echo $errors["expenses"]; ?>
			  </span>

		      <label for="amount">Amount</label>
		      <input type="number" id="amount" name="amount" placeholder="Amount">

		      <span class="errors">
				<?php echo $errors["amount"]; ?>
			  </span>

		      <label for="description">Particulars</label>
		      <textarea id="description" name="description" placeholder="Description"></textarea>

		      <span class="errors">
				<?php echo $errors["desc"]; ?>
			  </span>

		      <button class="btn" type="submit" name="submit">Add Expense</button>
		    </form>
		</section>
	</main>
	<script>
		<?php include "../dashboard/dash.js"; ?>
	</script>
</body>
</html>



	